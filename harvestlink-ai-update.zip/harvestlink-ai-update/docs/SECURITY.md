# Security baseline

## Implemented
- Passwords are hashed with Argon2 through pwdlib. Login does equal work for unknown accounts to limit timing-based account discovery.
- JWT bearer tokens (HS256) carry the user ID, require `exp` and `sub`, and are rejected when the user is missing or deactivated.
- The app refuses to start outside development with the built-in dev secret, a placeholder or short (<32 character) `SECRET_KEY`, `DEBUG=true`, or a wildcard in `CORS_ORIGINS`.
- Public registration only assigns the farmer role and rejects unknown fields such as `role`. Privileged roles require a separate administrative process. `require_roles(...)` guards role-restricted endpoints.
- Failed logins are rate limited per client address and email (default 5 per 15 minutes, then HTTP 429). The limiter is in memory and per process; use a shared store such as Redis when running several workers or replicas.
- CORS allows only the origins in `CORS_ORIGINS`. Responses carry `X-Content-Type-Options`, `X-Frame-Options` and `Referrer-Policy`, and `/api/` responses are `Cache-Control: no-store`. Interactive API docs are served only in development.
- `/health` returns HTTP 503 when the database is unreachable. The container runs as a non-root user with a health check, and CI runs with read-only repository permissions.

## Still to do
- Keep secrets outside source control and generate a unique `SECRET_KEY` for every deployment.
- Add authorization and organization isolation to every protected business endpoint as those modules are introduced.
- Use HTTPS, upload validation, database migrations, backups and tested restoration. When running behind a reverse proxy, make client IP detection trust only that proxy.
- Never log passwords or bearer tokens.

This baseline is not a completed security audit.
