from datetime import UTC, datetime, timedelta

import jwt
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from sqlalchemy.exc import OperationalError

from app.core.config import get_settings
from app.db import get_db
from app.dependencies import require_roles
from app.main import app
from app.models import User
from app.security import create_access_token, hash_password

REGISTER = "/api/v1/auth/register"
LOGIN = "/api/v1/auth/login"
ME = "/api/v1/auth/me"
PASSWORD = "secure-pass-123"


def user_data(email="farmer@example.com"):
    return {"email": email, "full_name": "Amina Farmer", "password": PASSWORD}


def register_and_login(client, email="farmer@example.com"):
    assert client.post(REGISTER, json=user_data(email)).status_code == 201
    response = client.post(LOGIN, json={"email": email, "password": PASSWORD})
    assert response.status_code == 200
    return response.json()["access_token"]


def bearer(token):
    return {"Authorization": f"Bearer {token}"}


def make_token(subject, *, expires_in=timedelta(minutes=5), key=None):
    now = datetime.now(UTC)
    payload = {"sub": subject, "iat": now, "exp": now + expires_in}
    return jwt.encode(payload, key or get_settings().secret_key, algorithm="HS256")


def test_health_ok(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "database": "ok"}


def test_health_returns_503_when_database_is_down(client):
    class BrokenSession:
        def execute(self, *args, **kwargs):
            raise OperationalError("SELECT 1", {}, Exception("database unavailable"))

    app.dependency_overrides[get_db] = lambda: BrokenSession()
    response = client.get("/health")
    assert response.status_code == 503
    assert response.json()["status"] == "degraded"


def test_register_duplicate_login_me(client):
    data = user_data()
    assert client.post(REGISTER, json=data).status_code == 201
    assert client.post(REGISTER, json=data).status_code == 409
    login = client.post(LOGIN, json={"email": "FARMER@example.com", "password": PASSWORD})
    assert login.status_code == 200
    profile = client.get(ME, headers=bearer(login.json()["access_token"]))
    assert profile.status_code == 200
    assert profile.json()["role"] == "farmer"
    assert "password" not in profile.text


def test_register_rejects_role_field(client):
    response = client.post(REGISTER, json={**user_data(), "role": "admin"})
    assert response.status_code == 422


def test_register_rejects_short_password(client):
    response = client.post(REGISTER, json={**user_data(), "password": "short"})
    assert response.status_code == 422


def test_wrong_password(client):
    client.post(REGISTER, json=user_data("buyer@example.com"))
    response = client.post(LOGIN, json={"email": "buyer@example.com", "password": "wrong-password"})
    assert response.status_code == 401


def test_unknown_user_gets_same_error_as_wrong_password(client):
    client.post(REGISTER, json=user_data("buyer@example.com"))
    wrong = client.post(LOGIN, json={"email": "buyer@example.com", "password": "wrong-password"})
    unknown = client.post(LOGIN, json={"email": "nobody@example.com", "password": "wrong-password"})
    assert unknown.status_code == wrong.status_code == 401
    assert unknown.json() == wrong.json()


def test_me_requires_token(client):
    assert client.get(ME).status_code == 401


def test_garbage_token_rejected(client):
    assert client.get(ME, headers=bearer("not-a-jwt")).status_code == 401


def test_expired_token_rejected(client):
    register_and_login(client)
    expired = make_token("1", expires_in=timedelta(minutes=-1))
    assert client.get(ME, headers=bearer(expired)).status_code == 401


def test_token_signed_with_wrong_key_rejected(client):
    register_and_login(client)
    forged = make_token("1", key="x" * 40)
    assert client.get(ME, headers=bearer(forged)).status_code == 401


def test_token_with_non_numeric_subject_rejected(client):
    register_and_login(client)
    token = make_token("farmer@example.com")
    assert client.get(ME, headers=bearer(token)).status_code == 401


def test_token_without_expiry_rejected(client):
    register_and_login(client)
    token = jwt.encode({"sub": "1"}, get_settings().secret_key, algorithm="HS256")
    assert client.get(ME, headers=bearer(token)).status_code == 401


def test_deactivated_user_loses_access(client, session_factory):
    token = register_and_login(client)
    assert client.get(ME, headers=bearer(token)).status_code == 200
    with session_factory() as db:
        user = db.query(User).filter(User.email == "farmer@example.com").one()
        user.is_active = False
        db.commit()
    assert client.get(ME, headers=bearer(token)).status_code == 401
    response = client.post(LOGIN, json={"email": "farmer@example.com", "password": PASSWORD})
    assert response.status_code == 401


def test_login_is_rate_limited_after_repeated_failures(client):
    client.post(REGISTER, json=user_data())
    bad = {"email": "farmer@example.com", "password": "wrong-password"}
    for _ in range(get_settings().login_max_failed_attempts):
        assert client.post(LOGIN, json=bad).status_code == 401
    blocked = client.post(LOGIN, json=bad)
    assert blocked.status_code == 429
    assert "retry-after" in blocked.headers
    # Even the correct password is refused while locked out.
    good = {"email": "farmer@example.com", "password": PASSWORD}
    assert client.post(LOGIN, json=good).status_code == 429


def test_successful_login_resets_failure_count(client):
    client.post(REGISTER, json=user_data())
    bad = {"email": "farmer@example.com", "password": "wrong-password"}
    good = {"email": "farmer@example.com", "password": PASSWORD}
    almost = get_settings().login_max_failed_attempts - 1
    for _ in range(almost):
        assert client.post(LOGIN, json=bad).status_code == 401
    assert client.post(LOGIN, json=good).status_code == 200
    for _ in range(almost):
        assert client.post(LOGIN, json=bad).status_code == 401


def test_require_roles_enforces_role(session_factory, db_override):
    probe = FastAPI()
    admin_required = Depends(require_roles("admin"))

    @probe.get("/admin-only")
    def admin_only(user: User = admin_required):
        return {"email": user.email}

    probe.dependency_overrides[get_db] = db_override
    with session_factory() as db:
        admin = User(email="a@example.com", full_name="Admin", role="admin",
                     password_hash=hash_password(PASSWORD))
        farmer = User(email="f@example.com", full_name="Farmer", role="farmer",
                      password_hash=hash_password(PASSWORD))
        db.add_all([admin, farmer])
        db.commit()
        admin_token = create_access_token(str(admin.id))
        farmer_token = create_access_token(str(farmer.id))
    with TestClient(probe) as probe_client:
        assert probe_client.get("/admin-only", headers=bearer(farmer_token)).status_code == 403
        allowed = probe_client.get("/admin-only", headers=bearer(admin_token))
        assert allowed.status_code == 200
        assert probe_client.get("/admin-only").status_code == 401


def test_security_headers_present(client):
    response = client.get("/health")
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-frame-options"] == "DENY"
    assert response.headers["referrer-policy"] == "no-referrer"
    api_response = client.post(LOGIN, json={"email": "x@example.com", "password": "whatever"})
    assert api_response.headers["cache-control"] == "no-store"


def test_cors_allows_configured_origin_only(client):
    request_headers = {"Access-Control-Request-Method": "POST"}
    allowed = client.options(LOGIN, headers={**request_headers, "Origin": "http://localhost:3000"})
    assert allowed.headers.get("access-control-allow-origin") == "http://localhost:3000"
    denied = client.options(LOGIN, headers={**request_headers, "Origin": "https://evil.example"})
    assert "access-control-allow-origin" not in denied.headers
