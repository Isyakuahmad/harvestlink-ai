import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import sessionmaker

from app.db import Base, build_engine, get_db
from app.main import app
from app.security import login_limiter


@pytest.fixture(autouse=True)
def _reset_login_limiter():
    login_limiter.reset()
    yield
    login_limiter.reset()


@pytest.fixture
def session_factory(tmp_path):
    engine = build_engine(f"sqlite:///{tmp_path / 'test.db'}")
    Base.metadata.create_all(bind=engine)
    yield sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.drop_all(bind=engine)
    engine.dispose()


@pytest.fixture
def db_override(session_factory):
    def override_db():
        db = session_factory()
        try:
            yield db
        finally:
            db.close()

    return override_db


@pytest.fixture
def client(db_override):
    app.dependency_overrides[get_db] = db_override
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
