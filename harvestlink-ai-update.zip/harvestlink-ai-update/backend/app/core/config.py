from functools import lru_cache
from typing import Self

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

DEV_SECRET_KEY = "dev-only-insecure-secret-key-do-not-use-in-production"
PLACEHOLDER_SECRET_PREFIX = "replace-with"
MIN_SECRET_LENGTH = 32


class Settings(BaseSettings):
    app_name: str = "HarvestLink AI"
    environment: str = "development"
    debug: bool = False
    database_url: str = "sqlite:///./harvestlink.db"
    secret_key: str = DEV_SECRET_KEY
    access_token_expire_minutes: int = 30
    cors_origins: str = "http://localhost:3000"
    login_max_failed_attempts: int = 5
    login_lockout_seconds: int = 900
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def is_development(self) -> bool:
        return self.environment == "development"

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @model_validator(mode="after")
    def reject_unsafe_configuration(self) -> Self:
        """Refuse to start outside development with insecure defaults."""
        if self.is_development:
            return self
        problems = []
        if (
            self.secret_key == DEV_SECRET_KEY
            or self.secret_key.startswith(PLACEHOLDER_SECRET_PREFIX)
            or len(self.secret_key) < MIN_SECRET_LENGTH
        ):
            problems.append(
                f"SECRET_KEY must be a unique random value of at least "
                f"{MIN_SECRET_LENGTH} characters"
            )
        if self.debug:
            problems.append("DEBUG must be false")
        if "*" in self.cors_origin_list:
            problems.append("CORS_ORIGINS must list explicit origins, not '*'")
        if problems:
            raise ValueError(
                f"Unsafe configuration for ENVIRONMENT={self.environment!r}: " + "; ".join(problems)
            )
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
