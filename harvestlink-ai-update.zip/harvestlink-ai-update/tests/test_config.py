import pytest

from app.core.config import DEV_SECRET_KEY, Settings

GOOD_SECRET = "k8Qz3v9Lw2Xr7Tn5Bd1Hs6Jp4Mc0Yf8A"


def build(**overrides):
    return Settings(_env_file=None, **overrides)


def test_development_allows_default_secret():
    settings = build(environment="development")
    assert settings.secret_key == DEV_SECRET_KEY
    assert len(settings.secret_key) >= 32


def test_production_rejects_default_secret():
    with pytest.raises(ValueError, match="SECRET_KEY"):
        build(environment="production")


def test_production_rejects_short_secret():
    with pytest.raises(ValueError, match="SECRET_KEY"):
        build(environment="production", secret_key="too-short")


def test_production_rejects_placeholder_secret():
    placeholder = "replace-with-a-long-random-secret-before-deployment"
    with pytest.raises(ValueError, match="SECRET_KEY"):
        build(environment="production", secret_key=placeholder)


def test_production_rejects_debug_and_wildcard_cors():
    with pytest.raises(ValueError, match="DEBUG"):
        build(environment="production", secret_key=GOOD_SECRET, debug=True)
    with pytest.raises(ValueError, match="CORS_ORIGINS"):
        build(environment="production", secret_key=GOOD_SECRET, cors_origins="*")


def test_production_accepts_safe_configuration():
    settings = build(
        environment="production",
        secret_key=GOOD_SECRET,
        cors_origins="https://app.example.com, https://admin.example.com",
    )
    assert settings.cors_origin_list == ["https://app.example.com", "https://admin.example.com"]
