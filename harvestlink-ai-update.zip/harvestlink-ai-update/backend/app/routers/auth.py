from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.db import get_db
from app.dependencies import get_current_user
from app.models import User
from app.schemas import TokenResponse, UserLogin, UserPublic, UserRegister
from app.security import (
    create_access_token,
    hash_password,
    login_limiter,
    verify_password_or_dummy,
)

router = APIRouter(prefix="/api/v1/auth", tags=["authentication"])


@router.post("/register", response_model=UserPublic, status_code=201)
def register(payload: UserRegister, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = User(
        email=email,
        full_name=payload.full_name.strip(),
        password_hash=hash_password(payload.password),
        role="farmer",
    )
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        # Lost a race with a concurrent registration for the same email.
        db.rollback()
        raise HTTPException(
            status_code=409, detail="An account with this email already exists"
        ) from None
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenResponse)
def login(payload: UserLogin, request: Request, db: Session = Depends(get_db)):
    email = payload.email.lower()
    client_host = request.client.host if request.client else "unknown"
    limiter_key = f"{client_host}:{email}"
    if login_limiter.is_blocked(limiter_key):
        raise HTTPException(
            status_code=429,
            detail="Too many failed login attempts. Try again later.",
            headers={"Retry-After": str(login_limiter.window_seconds)},
        )
    user = db.query(User).filter(User.email == email).first()
    password_ok = verify_password_or_dummy(
        payload.password, user.password_hash if user is not None else None
    )
    if user is None or not user.is_active or not password_ok:
        login_limiter.record_failure(limiter_key)
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    login_limiter.reset(limiter_key)
    return TokenResponse(access_token=create_access_token(str(user.id)))


@router.get("/me", response_model=UserPublic)
def me(user: User = Depends(get_current_user)):
    return user
