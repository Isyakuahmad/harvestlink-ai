import threading
import time
from collections import defaultdict, deque
from datetime import UTC, datetime, timedelta

import jwt
from pwdlib import PasswordHash

from app.core.config import get_settings

_password_hash = PasswordHash.recommended()
# Verified against when an account does not exist, so response time does not reveal
# whether an email address is registered.
_DUMMY_HASH = _password_hash.hash("harvestlink-timing-equalizer")


def hash_password(password: str) -> str:
    return _password_hash.hash(password)


def verify_password(password: str, stored_hash: str) -> bool:
    return _password_hash.verify(password, stored_hash)


def verify_password_or_dummy(password: str, stored_hash: str | None) -> bool:
    """Verify a password, spending the same effort when the account is unknown."""
    if stored_hash is None:
        _password_hash.verify(password, _DUMMY_HASH)
        return False
    return _password_hash.verify(password, stored_hash)


def create_access_token(subject: str) -> str:
    settings = get_settings()
    now = datetime.now(UTC)
    payload = {
        "sub": subject,
        "iat": now,
        "exp": now + timedelta(minutes=settings.access_token_expire_minutes),
    }
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")


def decode_access_token(token: str) -> str:
    payload = jwt.decode(
        token,
        get_settings().secret_key,
        algorithms=["HS256"],
        options={"require": ["exp", "sub"]},
    )
    return str(payload["sub"])


class LoginRateLimiter:
    """In-memory sliding-window limiter for failed logins.

    State is per process: with several workers or replicas, move this to a shared
    store such as Redis.
    """

    def __init__(self, max_failures: int, window_seconds: int) -> None:
        self.max_failures = max_failures
        self.window_seconds = window_seconds
        self._failures: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def _recent(self, key: str, now: float) -> deque[float]:
        failures = self._failures[key]
        while failures and now - failures[0] > self.window_seconds:
            failures.popleft()
        return failures

    def is_blocked(self, key: str) -> bool:
        with self._lock:
            failures = self._recent(key, time.monotonic())
            if not failures:
                self._failures.pop(key, None)
            return len(failures) >= self.max_failures

    def record_failure(self, key: str) -> None:
        with self._lock:
            now = time.monotonic()
            self._recent(key, now).append(now)

    def reset(self, key: str | None = None) -> None:
        with self._lock:
            if key is None:
                self._failures.clear()
            else:
                self._failures.pop(key, None)


_settings = get_settings()
login_limiter = LoginRateLimiter(
    max_failures=_settings.login_max_failed_attempts,
    window_seconds=_settings.login_lockout_seconds,
)
